package com.mxn.soul.flowingdrawer;

public class Common {

    public static String currentToken = "";

}
