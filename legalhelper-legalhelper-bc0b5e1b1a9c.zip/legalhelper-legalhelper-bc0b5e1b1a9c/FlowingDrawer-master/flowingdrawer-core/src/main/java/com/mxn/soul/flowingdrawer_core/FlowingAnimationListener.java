package com.mxn.soul.flowingdrawer_core;


import com.nineoldandroids.animation.Animator;

class FlowingAnimationListener implements Animator.AnimatorListener {

    public void onAnimationStart(Animator animation) {

    }

    @Override
    public void onAnimationEnd(Animator animation) {

    }

    @Override
    public void onAnimationCancel(Animator animation) {

    }

    @Override
    public void onAnimationRepeat(Animator animation) {

    }

}
